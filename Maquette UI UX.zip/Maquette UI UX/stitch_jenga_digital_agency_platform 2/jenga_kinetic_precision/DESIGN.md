---
name: Jenga Kinetic Precision
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434656'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737688'
  outline-variant: '#c3c5d9'
  surface-tint: '#004ced'
  primary: '#003ec7'
  on-primary: '#ffffff'
  primary-container: '#0052ff'
  on-primary-container: '#dfe3ff'
  inverse-primary: '#b7c4ff'
  secondary: '#575e71'
  on-secondary: '#ffffff'
  secondary-container: '#d9dff6'
  on-secondary-container: '#5b6276'
  tertiary: '#005474'
  on-tertiary: '#ffffff'
  tertiary-container: '#006e95'
  on-tertiary-container: '#caeaff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001452'
  on-primary-fixed-variant: '#0038b6'
  secondary-fixed: '#dce2f9'
  secondary-fixed-dim: '#bfc6dc'
  on-secondary-fixed: '#141b2c'
  on-secondary-fixed-variant: '#404659'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 72px
    fontWeight: '800'
    lineHeight: 80px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-xl:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-code:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2.5rem
  margin: 1.5rem
  margin-sm: 1rem
  margin-md: 3rem
  margin-lg: 5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
---

## Brand & Style

This design system establishes a high-tier digital agency aesthetic rooted in architectural precision, technological authority, and refined kinetic elegance. Drawing inspiration from top-tier international digital ateliers, the visual tone departs from generic SaaS tropes to deliver a cinematic, authoritative, and master-crafted experience.

### Tone & Personality
- **Architectural & Rigorous:** Structured gridlines, surgical alignments, and deliberate typographic rhythm mirroring structural engineering.
- **Electric & Visionary:** Piercing cobalt and cyan accents slicing through pristine light and deep twilight environments, evoking computational speed and modern intelligence.
- **Executive Trust:** Uncompromising legibility, balanced density, and high-contrast composition designed for enterprise leaders and premium innovators.

### Design Movement
A fusion of **Neo-Architectural Precision** and **Controlled Tech Glassmorphism**. The interface relies on hairline semi-translucent borders, subtle ambient glow fields behind key interactions, ultra-smooth layer elevations, and crisp negative space.

## Colors

The color architecture is built around calibrated contrast tiers, combining ultra-refined cool slates with authoritative deep blues and high-velocity electric accents.

### Palette Architecture
- **Primary (`#0052FF`):** The electric pulse of the agency. Used for focal conversions, primary interactive nodes, and active state indicators.
- **Secondary / Deep Void (`#070E1E`):** Pure engineering depth. Utilized for high-impact display moments, navigation headers, dark-canvas showcases, and bold branding blocks.
- **Tertiary (`#38BDF8`):** Atmospheric cyan light. Reserved strictly for subtle micro-glows, technical chips, badge indicators, and dynamic metrics.
- **Neutral Core (`#0F172A`):** The primary typographic ink, delivering razor-sharp contrast against clean canvas backgrounds without the harshness of pure black.

### Surface System
- `canvas-default`: `#FFFFFF`
- `canvas-subtle`: `#F8FAFC`
- `canvas-elevated`: `#F1F5F9`
- `border-hairline`: `rgba(15, 23, 42, 0.08)` (Day) / `rgba(255, 255, 255, 0.12)` (Night)
- `border-active`: `#CBD5E1`
- `text-muted`: `#64748B`
- `text-secondary`: `#334155`

## Typography

The typographic hierarchy juxtaposes the contemporary geometric assertiveness of **Plus Jakarta Sans** with the unyielding technical clarity and structural rhythm of **Inter**.

### Rules & Application
- **Headlines & Metric Titles:** Use Plus Jakarta Sans with tightened negative tracking to establish architectural weight. Headings must stay disciplined; avoid excessive word wrapping on large breakpoints.
- **Narrative & Body:** Use Inter with generous line-height ratios (1.5x–1.6x) to preserve editorial white space, ensuring zero cognitive friction when reading case studies and technical architectures.
- **Code & Micro-Labels:** Micro-caps and metadata tags render in Inter with positive letter-spacing (`0.04em` to `0.08em`) to convey diagnostic, agency-grade precision.

## Layout & Spacing

The layout is grounded in a flexible 12-column responsive grid underpinned by an 8pt modular interval.

### Breakpoints & Canvas Constraints
- **Desktop (1440px+):** 12 columns, `margin-lg` (5rem/80px) outer padding, max container width of 1360px, gutter `2.5rem`.
- **Tablet (768px – 1024px):** 8 columns, `margin-md` (3rem/48px) outer padding, gutter `1.5rem`.
- **Mobile (320px – 767px):** 4 columns, `margin-sm` (1rem/16px) outer padding, gutter `1rem`.

### Spatial Rhythm
- Components leverage micro-tokens (`space-xs` through `space-md`) for sharp internal balance.
- Structural layout modules and project showpieces use macro-tokens (`space-2xl`, `space-3xl`) to create expansive visual breathing room reminiscent of bespoke physical architectural portfolios.

## Elevation & Depth

Visual hierarchy uses a refined dual-state shadow system combined with hairline borders and kinetic ambient glows.

### Elevation Levels
- **Level 0 (Flat Surface):** Flush with canvas, defined purely by `border-hairline` (1px `#E2E8F0` or `rgba(15, 23, 42, 0.06)`).
- **Level 1 (Card & Content Containers):**
  - Ambient base: `0 1px 3px rgba(15, 23, 42, 0.04)`
  - Key light: `0 4px 12px -2px rgba(15, 23, 42, 0.05)`
  - Border: 1px continuous solid `#E2E8F0`
- **Level 2 (Dropdowns, Floating Shells, Modals):**
  - Ambient base: `0 8px 24px -4px rgba(7, 14, 30, 0.08)`
  - Key light: `0 20px 48px -8px rgba(7, 14, 30, 0.12)`
  - Border: 1px continuous solid `rgba(226, 232, 240, 0.8)`
- **Level 3 (Electric Hover / Glow State):**
  - Card or button elevation shifts with an infused electric aura: `0 8px 30px -4px rgba(0, 82, 255, 0.25)`.
  - Dark-mode alternative: `0 0 40px -8px rgba(56, 189, 248, 0.3)`.

## Shapes

The design system employs a geometric, confident radius system (`roundedness: 2`). Corners remain intentionally structured rather than organic, communicating architectural stability and technological rigor.

- **Base radius (0.5rem / 8px):** Applied to buttons, input controls, small badges, and tooltips.
- **Large radius (1rem / 16px):** Applied to standard showcase cards, project tiles, and dynamic media viewports.
- **Extra-large radius (1.5rem / 24px):** Applied to hero panels, full-bleed modals, and parent modular containers.
- **Full Pill (`9999px`):** Reserved solely for category badges, dynamic status chips, and contextual floating action tags.

## Components

### Buttons
- **Primary Electric:** Deep blue background (`#0052FF`), crisp white text, 8px corner radius, hairline inset border (`rgba(255, 255, 255, 0.2)`). On hover, subtle vertical lift (`-1px`) accompanied by the cobalt glow (`0 8px 24px -4px rgba(0, 82, 255, 0.35)`).
- **Secondary Void:** Slate background (`#070E1E`), pure white text, hairline border (`rgba(255, 255, 255, 0.1)`). On hover, canvas background shifts to `#0A192F`.
- **Ghost / Minimalist:** Transparent surface, `#0F172A` text, 1px border `#E2E8F0`. Hover triggers background `#F8FAFC` and border `#CBD5E1`.

### Cards & Project Showcases
- Surface set to `#FFFFFF` (or `#0A192F` on dark canvases) paired with an uncompromising 1px border `#E2E8F0`.
- Integrated media assets feature subtle inset inner shadows.
- Hover transitions engage a smooth 200ms cubic bezier transition, escalating elevation to Level 2 and activating a hairline electric border accent.

### Chips & Technical Tags
- Compact height (24px to 28px), pill-shaped (`9999px`), rendered with muted backgrounds (`#F1F5F9`) and disciplined uppercase labels (`label-code` in `#334155`).
- Active status chips integrate a pulsating 6px cyan (`#38BDF8`) status beacon.

### Input Fields
- Structured surfaces with 8px radius, `#FFFFFF` background, and 1px border `#CBD5E1`.
- Focused state eliminates generic thick rings in favor of a crisp 1px `#0052FF` border accompanied by an ambient `0 0 0 3px rgba(0, 82, 255, 0.15)` focus spread.

### Checkboxes & Radio Controls
- High-precision 16px geometry. Default state features a subtle 1px border `#CBD5E1` against `#FFFFFF`.
- Checked state transitions cleanly to `#0052FF` with centered micro-geometry rendered in crisp white.

### Data Metric Panels & Bento Grids
- Bespoke agency showcase structures featuring asymmetric card spanning (e.g., 8-col case study paired with 4-col metric stack).
- Metric numerals are rendered in `display-hero` scale with high-contrast slate-to-cobalt linear gradients.